//Import express from previously installedd dependency
const express = require('express');
const app = express();
const db = require('./config/mongoose')

// In this port Our Server Will be Running 
const port = 8000;
const cookieParser = require('cookie-parser');
app.use(express.static('./assets'));
const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(express.urlencoded());
app.use(cookieParser());
//ejs as view engine
app.set('view engine','ejs');
app.set('views','./views')
app.listen(port,function(err)
{
    if(err)
    {
        console.log("Error In Running The Server", port);
        return;
    }
    else
    {
        console.log(`Server is up and running Fine : ${port}`);
        
    }
});
app.use('/',require('./routes/index'));