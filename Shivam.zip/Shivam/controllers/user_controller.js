const User = require('../models/users')

//Action for user Profile
module.exports.profile = function(req,res)
{
    if(req.cookies.user_id)
    {
        User.findById(req.cookies.user_id,function(err,user)
        {
            if(user)
            {
                
                
                return res.render('user_profile',
                    {
                        title:'User Profile',
                        user:user
                    });
            }
            else
            {
                return res.redirect('/user/sign-in');
            }
        });
    }
    else
    {
        
        return res.redirect('/user/sign-in');
    } 
}
//Action for user Sign-up
module.exports.sign_up = function(req,res)
{
    return res.render('User_sign_up',
    {
        title:"Sign Up"
    })
}
//Action for user Sign-in
module.exports.sign_in = function(req,res)
{
    return res.render('User_sign_in',
    {
        title:"Sign in"
    })
}
//For Creating account which will be saved in dataBase
module.exports.create=function(req,res)
{

    if(req.body.password!=req.body.Confirm_password)
    {
        console.log("Well Your Password doesn't match");
        return res.redirect('back');
    }
    User.findOne({email:req.body.email},function(err,user)
    {
        if(err)
        {
            console.log("Error in finding user in Signing up");
            return;
        }
        if(!user)
        {
            User.create(req.body,function(err,user)
            {
                if(err)
                {
                    console.log("error in creating account");
                    return;  
                }
                    return res.redirect('/user/sign-in');
            });
           
        }
        else
        {
            return res.redirect('back');
        }
    });
}

// When User in logged in a session will be created so user does'nt have to log in again
module.exports.createSession=function(req,res)
{
    User.findOne({email:req.body.email},function(err,user)
    {
        if(err)
        {
            console.log("Error in Finding the User");
            return;
        }
        if(user)
        {
            if(user.password!=req.body.password)
            {
                console.log("Password not matched");
                return res.redirect('back');
            }
                console.log("ser logged in");
                
                res.cookie("user_id",user.id);
                return res.redirect('/user/profile');
        }
        else
        {

            return res.redirect('back' );
        }
    });   
}